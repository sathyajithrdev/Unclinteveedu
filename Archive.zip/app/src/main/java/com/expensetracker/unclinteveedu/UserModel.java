package com.expensetracker.unclinteveedu;

/**
 * Created by sathyajith on 17/07/17.
 */

public class UserModel {
    public String userName;
    public String name;
    public String profileImage;
}
